# RUN.md - how to run the Agentic AI Testing Knowledge Assistant

Tested on a clean checkout. Default run needs **no API key, no cloud, no cost**
(it uses the deterministic `FakeModelClient`). Target: running in under 15 minutes.

## 1. Prerequisites
- Python 3.10 or newer (`python --version`)
- git

## 2. Setup (clean checkout)
```bash
git clone <your-repo-url>
cd agentic-testing-assistant

python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt   # installs pytest only
```

## 3. Run the tests (should be all green)
```bash
python -m pytest -q
```
Expected: `19 passed`.

## 4. Run the evaluation gate
```bash
python -m eval.run_eval
```
Expected: `Pass-rate (code checks): 100%` and `GATE PASSED`.

## 5. Ask the agent a question
```bash
python -m src.agent "How do you test a system that gives a different answer every time?"
python -m src.agent "What is the capital of France?"     # watch it refuse
```

## 6. See the orchestration (approval + handoff)
```bash
python -m src.orchestration
```

## 7. Optional - use the real Gemini model instead of the fake
```bash
# Windows PowerShell:
$env:AGENT_MODEL="gemini"; $env:GEMINI_API_KEY="<your-key>"
pip install google-generativeai
python -m src.agent "When should a grounded agent refuse to answer?"
```
Leave `AGENT_MODEL` unset for the default, offline deterministic run.
