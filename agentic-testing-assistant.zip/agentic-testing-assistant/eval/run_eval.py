"""
run_eval.py - runs the golden set, scores it, and ENFORCES A GATE (Review Area 5).

Exit code 0 if the pass-rate meets the threshold, 1 if not. The CI workflow runs
this, so a regression that drops the score below the threshold BLOCKS the pipeline.

Usage:
    python -m eval.run_eval
    python -m eval.run_eval --threshold 0.85
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from eval.evaluators import check_case, llm_judge
from src.agent import Agent

GOLDEN = Path(__file__).resolve().parent / "golden_dataset.json"
DEFAULT_THRESHOLD = 0.85


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD)
    args = parser.parse_args()

    data = json.loads(GOLDEN.read_text(encoding="utf-8"))
    cases = data["cases"]
    agent = Agent()

    passed = 0
    failures: list[str] = []
    judge_scores: list[float] = []

    print(f"Running {len(cases)} golden cases (dataset v{data['version']})...\n")
    for case in cases:
        result = agent.answer(case["question"])
        ok, reason = check_case(case, result)
        judge = llm_judge(case["question"], result.answer.answer)
        judge_scores.append(judge)
        print(f"  [{'PASS' if ok else 'FAIL'}] {case['id']:<20} judge={judge:<4} {reason}")
        if ok:
            passed += 1
        else:
            failures.append(f"{case['id']}: {reason}")

    pass_rate = passed / len(cases)
    avg_judge = sum(judge_scores) / len(judge_scores)

    print("\n" + "-" * 60)
    print(f"Pass-rate (code checks): {pass_rate:.0%}  ({passed}/{len(cases)})")
    print(f"Avg relevance (judge):   {avg_judge:.2f}")
    print(f"Gate threshold:          {args.threshold:.0%}")
    if failures:
        print("\nTop failure modes:")
        for f in failures:
            print(f"  - {f}")

    if pass_rate >= args.threshold:
        print(f"\nGATE PASSED ({pass_rate:.0%} >= {args.threshold:.0%})")
        return 0
    print(f"\nGATE FAILED ({pass_rate:.0%} < {args.threshold:.0%})")
    return 1


if __name__ == "__main__":
    sys.exit(main())
