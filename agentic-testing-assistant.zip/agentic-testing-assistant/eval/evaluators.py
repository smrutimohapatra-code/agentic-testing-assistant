"""
evaluators.py - the two KINDS of evaluator, and WHY the split (Review Area 3).

CODE-BASED checks  -> objective, exact, cheap: right citation? correct fact?
                      refused when it should? Use code whenever the check is exact.
LLM-JUDGE check    -> subjective: is the answer actually relevant/on-topic? Use a
                      judge only for what code cannot verify.
"""

from __future__ import annotations

import re

from src.agent import AgentResult, REFUSAL_MESSAGE


def check_case(case: dict, result: AgentResult) -> tuple[bool, str]:
    """Exact, deterministic pass/fail for one golden case (CODE-BASED)."""
    answer = result.answer.answer

    if case["type"] == "refuse":
        if answer == REFUSAL_MESSAGE and not result.answer.citations:
            return True, "correctly refused"
        return False, f"should have refused, but answered: {answer[:60]!r}"

    if answer == REFUSAL_MESSAGE:
        return False, "refused a question it should have answered"
    if case["expected_doc"] not in result.answer.citations:
        return False, f"missing expected citation {case['expected_doc']}; got {result.answer.citations}"
    for needle in case.get("must_include", []):
        if needle.lower() not in answer.lower():
            return False, f"answer missing required fact {needle!r}"
    return True, "grounded, cited, correct fact"


def llm_judge(question: str, answer: str) -> float:
    """Score answer relevance 0..1 (the LLM-JUDGE role).

    In AGENT_MODEL=gemini mode this would prompt the LLM to grade relevance.
    Offline we use a deterministic relevance heuristic (share of the question's
    content words the answer addresses), playing the same role while staying runnable.
    """
    if answer == REFUSAL_MESSAGE:
        return 0.0
    q_words = {w for w in re.findall(r"[a-z0-9]+", question.lower()) if len(w) > 3}
    a_words = {w for w in re.findall(r"[a-z0-9]+", answer.lower()) if len(w) > 3}
    if not q_words:
        return 1.0
    return round(len(q_words & a_words) / len(q_words), 2)
