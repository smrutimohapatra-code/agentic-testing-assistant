"""Area 1 - Structured-output tests: the validator catches malformed and
out-of-distribution model responses, not just the happy path."""

import pytest

from src.schema import SchemaError, parse_answer


def test_valid_response_parses():
    raw = '{"answer": "use a deterministic double", "citations": ["grounding"], "confidence": 0.9}'
    result = parse_answer(raw)
    assert result.citations == ["grounding"]
    assert result.confidence == 0.9


def test_malformed_json_is_rejected():
    with pytest.raises(SchemaError):
        parse_answer('{not valid json')


def test_missing_field_is_rejected():
    with pytest.raises(SchemaError):
        parse_answer('{"answer": "x", "citations": []}')


def test_wrong_type_is_rejected():
    with pytest.raises(SchemaError):
        parse_answer('{"answer": "x", "citations": "grounding", "confidence": 0.5}')


def test_out_of_range_confidence_is_rejected():
    with pytest.raises(SchemaError):
        parse_answer('{"answer": "x", "citations": [], "confidence": 7.0}')


def test_non_object_is_rejected():
    with pytest.raises(SchemaError):
        parse_answer('["not", "an", "object"]')
