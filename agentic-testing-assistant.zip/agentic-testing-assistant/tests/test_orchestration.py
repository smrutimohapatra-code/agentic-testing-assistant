"""Area 4 - orchestration tests: approval pause/resume, scoped permissions, and a
deliberately failed handoff recovered by the escalation agent."""

from src.orchestration import KnowledgeBackend, Orchestrator


def test_action_pauses_for_approval():
    orch = Orchestrator()
    result = orch.handle("Please submit a correction to the grounding entry", user_role="contributor")
    assert result.needs_approval is True
    assert result.token is not None
    assert orch.backend.changes == []        # nothing applied yet, only paused


def test_maintainer_can_approve_and_resume_with_memory():
    orch = Orchestrator()
    paused = orch.handle("Please submit a correction to the agent-core entry")
    done = orch.resume(paused.token, approver_role="maintainer", approved=True)
    assert "Approved and applied" in done.answer
    assert len(orch.backend.changes) == 1    # the remembered action ran


def test_contributor_cannot_approve_scope_enforced():
    orch = Orchestrator()
    paused = orch.handle("Please submit a correction to the grounding entry")
    denied = orch.resume(paused.token, approver_role="contributor", approved=True)
    assert "not authorised" in denied.answer
    assert orch.backend.changes == []


def test_handoff_to_escalation_on_unanswerable_question():
    orch = Orchestrator()
    result = orch.handle("What is the capital of France?")
    assert result.handoff is True
    assert "escalated" in result.answer.lower()
    names = [s.name for s in result.trace]
    assert "refuse" in names and "handoff" in names


def test_deliberately_failed_handoff_is_retried_by_escalation():
    backend = KnowledgeBackend()
    backend._fail_ticket_once = True          # force the first ticket attempt to fail
    orch = Orchestrator(backend=backend)
    result = orch.handle("What is the weather forecast tomorrow?")
    assert result.handoff is True
    assert "Ticket #1" in result.answer
    assert any(s.name == "handoff_error" for s in result.trace)
