"""Area 2 - Tool-failure recovery and the max-iteration guard. A 'killed tool'
and a broken model must degrade to a safe refusal, not crash or loop forever."""

from src.agent import Agent, REFUSAL_MESSAGE
from src.model_client import ModelClient


class _FlakyRetriever:
    def retrieve(self, question, k=3):
        raise ConnectionError("vector store unavailable")


class _BrokenModel(ModelClient):
    name = "broken"

    def answer(self, question, context):
        return "this is not json"


def test_retriever_failure_recovers_to_refusal():
    agent = Agent(retriever=_FlakyRetriever(), max_tool_retries=2)
    result = agent.answer("What stops an agent loop from running forever?")
    assert result.answer.answer == REFUSAL_MESSAGE
    assert any(s.name == "retrieve_error" for s in result.trace)


def test_broken_model_hits_iteration_guard_and_refuses():
    agent = Agent(model=_BrokenModel(), max_iterations=3)
    result = agent.answer("What stops an agent loop from running forever?")
    assert result.answer.answer == REFUSAL_MESSAGE
    schema_errors = [s for s in result.trace if s.name == "schema_error"]
    assert len(schema_errors) == 3
