"""Area 2 - Grounding tests: grounded+cited answers, refusal of out-of-corpus
questions, and blocking an answer whose citation does not resolve."""

import json

from src.agent import Agent, REFUSAL_MESSAGE
from src.model_client import ModelClient


def test_in_corpus_question_is_grounded_and_cited():
    result = Agent().answer("How do you test a system that gives a different answer every time?")
    assert result.answer.answer != REFUSAL_MESSAGE
    assert "testing-nondeterminism" in result.answer.citations
    assert "meaning" in result.answer.answer.lower()


def test_out_of_corpus_question_is_refused():
    result = Agent().answer("What is the capital of France?")
    assert result.answer.answer == REFUSAL_MESSAGE
    assert result.answer.citations == []


class _BadCitationModel(ModelClient):
    """A model that invents a citation to a document that was never retrieved."""
    name = "bad-citation"

    def answer(self, question, context):
        return json.dumps({
            "answer": "Agents never need citations.",
            "citations": ["does-not-exist"],
            "confidence": 0.99,
        })


def test_unresolved_citation_is_blocked():
    agent = Agent(model=_BadCitationModel())
    result = agent.answer("When should a grounded agent refuse to answer?")
    assert result.answer.answer == REFUSAL_MESSAGE
