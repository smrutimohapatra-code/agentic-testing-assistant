"""Makes `import src...` work from anywhere pytest is invoked by putting the
project root on the import path."""
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
