"""
guardrails.py - input and output safety checks (Review Area 3).

1. scan_input()  -> block prompt-injection attempts BEFORE they reach the model.
2. redact_pii()  -> strip personal data (emails, phones, ids) from the OUTPUT.

Rule-based, explainable, and each rule maps to a case in security/red_team.md.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_INJECTION_PATTERNS = [
    r"ignore (all |the )?(previous|above) (instructions|prompt)",
    r"disregard (the |all )?(previous|above)",
    r"reveal (your )?(system )?(prompt|instructions)",
    r"you are now",
    r"developer mode",
    r"forget (everything|all) (you|your)",
]

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(r"\b(?:\+?\d[\d -]{7,}\d)\b")
_EMPID_RE = re.compile(r"\bEMP\d{3,}\b", re.IGNORECASE)


@dataclass
class GuardrailResult:
    blocked: bool
    reason: str
    text: str


def scan_input(text: str) -> GuardrailResult:
    lowered = text.lower()
    for pattern in _INJECTION_PATTERNS:
        if re.search(pattern, lowered):
            return GuardrailResult(True, f"prompt_injection_detected: /{pattern}/", text)
    return GuardrailResult(False, "", text)


def redact_pii(text: str) -> tuple[str, bool]:
    found = False
    for regex, label in ((_EMAIL_RE, "EMAIL"), (_PHONE_RE, "PHONE"), (_EMPID_RE, "ID")):
        if regex.search(text):
            found = True
            text = regex.sub(f"[REDACTED_{label}]", text)
    return text, found


def scan_output(text: str) -> tuple[str, bool]:
    return redact_pii(text)
