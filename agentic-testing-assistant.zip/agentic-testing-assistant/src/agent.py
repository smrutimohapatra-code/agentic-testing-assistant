"""
agent.py - the agent core (Review Area 2, with Area 3 tracing baked in).

The answer() pipeline, in order:
  1. INPUT GUARDRAIL   - block prompt injection before anything runs.
  2. RETRIEVE (tool)   - with failure recovery (retries) so a flaky tool does
                         not crash the run.
  3. MODEL + SCHEMA    - call the model, validate its JSON; retry up to a
                         MAXIMUM-ITERATION guard so a bad model can't loop forever.
  4. CITATION CHECK    - every cited doc_id must resolve to a retrieved chunk;
                         an answer with no valid citation is downgraded to a refusal.
  5. REFUSAL           - if the model/corpus can't answer, return a safe refusal.
  6. OUTPUT GUARDRAIL  - redact any PII before returning.

Every step appends a Span to `trace` - the observability (Area 3).
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from src import guardrails
from src.model_client import ModelClient, get_model_client
from src.retriever import Retriever
from src.schema import AgentAnswer, REFUSAL, SchemaError, parse_answer

REFUSAL_MESSAGE = (
    "I can't answer that from the current knowledge base. "
    "Please consult the source material or a human expert."
)


@dataclass
class Span:
    name: str
    info: str
    ms: float = 0.0


@dataclass
class AgentResult:
    answer: AgentAnswer
    trace: list[Span] = field(default_factory=list)
    blocked: bool = False

    def pretty_trace(self) -> str:
        return "\n".join(f"  [{s.ms:6.1f}ms] {s.name}: {s.info}" for s in self.trace)


class Agent:
    def __init__(self, model: ModelClient | None = None, retriever: Retriever | None = None,
                 max_iterations: int = 3, max_tool_retries: int = 2, min_confidence: float = 0.0):
        self.model = model or get_model_client()
        self.retriever = retriever or Retriever()
        self.max_iterations = max_iterations
        self.max_tool_retries = max_tool_retries
        self.min_confidence = min_confidence

    def _retrieve_with_recovery(self, question: str, trace: list[Span]):
        """Call the retriever, retrying on failure. A flaky tool is recovered,
        not fatal. Returns the chunks, or [] if the tool never succeeds."""
        for attempt in range(1, self.max_tool_retries + 2):
            start = time.perf_counter()
            try:
                chunks = self.retriever.retrieve(question)
                trace.append(Span("retrieve", f"attempt {attempt}: {len(chunks)} chunks",
                                  (time.perf_counter() - start) * 1000))
                return chunks
            except Exception as e:
                trace.append(Span("retrieve_error", f"attempt {attempt} failed: {e}",
                                  (time.perf_counter() - start) * 1000))
        trace.append(Span("retrieve_gaveup", "all retries failed -> refusing", 0.0))
        return []

    def answer(self, question: str) -> AgentResult:
        trace: list[Span] = []

        # 1. INPUT GUARDRAIL
        guard = guardrails.scan_input(question)
        if guard.blocked:
            trace.append(Span("input_guardrail", f"BLOCKED ({guard.reason})"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace, blocked=True)
        trace.append(Span("input_guardrail", "passed"))

        # 2. RETRIEVE (with recovery)
        context = self._retrieve_with_recovery(question, trace)
        if not context:
            trace.append(Span("refuse", "no context retrieved"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace)
        retrieved_ids = {c.doc_id for c in context}

        # 3. MODEL + SCHEMA, bounded by the max-iteration guard
        parsed: AgentAnswer | None = None
        for iteration in range(1, self.max_iterations + 1):
            start = time.perf_counter()
            raw = self.model.answer(question, context)
            try:
                parsed = parse_answer(raw)
                trace.append(Span("model", f"iter {iteration} via '{self.model.name}' ok",
                                  (time.perf_counter() - start) * 1000))
                break
            except SchemaError as e:
                trace.append(Span("schema_error", f"iter {iteration}: {e}",
                                  (time.perf_counter() - start) * 1000))
        if parsed is None:
            trace.append(Span("refuse", "model never returned valid schema"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace)

        # 3b. explicit model refusal
        if parsed.answer.strip() == REFUSAL:
            trace.append(Span("refuse", "model returned INSUFFICIENT_CONTEXT"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace)

        # 4. CITATION CHECK
        valid = [c for c in parsed.citations if c in retrieved_ids]
        dropped = [c for c in parsed.citations if c not in retrieved_ids]
        if dropped:
            trace.append(Span("citation_check", f"dropped unresolved: {dropped}"))
        if not valid:
            trace.append(Span("refuse", "no valid citation -> ungrounded answer blocked"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace)
        trace.append(Span("citation_check", f"grounded in {valid}"))

        # 4b. confidence gate (optional)
        if parsed.confidence < self.min_confidence:
            trace.append(Span("refuse", f"confidence {parsed.confidence} < {self.min_confidence}"))
            return AgentResult(AgentAnswer(REFUSAL_MESSAGE, [], 0.0), trace)

        # 5/6. OUTPUT GUARDRAIL (PII redaction) then return
        clean, had_pii = guardrails.scan_output(parsed.answer)
        if had_pii:
            trace.append(Span("output_guardrail", "PII redacted"))
        final = AgentAnswer(answer=clean, citations=valid, confidence=parsed.confidence)
        trace.append(Span("done", f"confidence={parsed.confidence}"))
        return AgentResult(final, trace)


if __name__ == "__main__":
    import sys
    q = sys.argv[1] if len(sys.argv) > 1 else "How do you test a system that gives a different answer every time?"
    result = Agent().answer(q)
    print("Q:", q)
    print("A:", result.answer.answer)
    print("Citations:", result.answer.citations, "| confidence:", result.answer.confidence)
    print("Trace:")
    print(result.pretty_trace())
