"""
model_client.py - the swappable "brain" of the agent (keystone design decision).

The track's defining question is "how do you verify a system that answers
differently every time?" Answer: put the model behind an interface and inject a
DETERMINISTIC fake for tests and local runs.

- FakeModelClient   -> no API key, no cloud, same answer every time (DEFAULT).
- GeminiModelClient -> the real LLM, used only if AGENT_MODEL=gemini + a key.
"""

from __future__ import annotations

import json
import os
import re
from abc import ABC, abstractmethod

from src.schema import Chunk, REFUSAL

_STOPWORDS = {
    "a", "an", "the", "is", "are", "am", "do", "does", "how", "what", "when",
    "where", "which", "who", "can", "i", "we", "you", "to", "of", "for", "in",
    "on", "my", "me", "and", "or", "per", "much", "many", "get", "got", "have",
    # Low-signal temporal words - too common to indicate topic (kept in sync with retriever.py)
    "year", "years", "next", "day", "days", "week", "weeks", "month", "months",
    "time", "calendar", "last", "upcoming", "will", "be",
}


def _keywords(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {w for w in words if w not in _STOPWORDS and len(w) > 2}


class ModelClient(ABC):
    name: str = "base"

    @abstractmethod
    def answer(self, question: str, context: list[Chunk]) -> str:
        ...


class FakeModelClient(ModelClient):
    """Deterministic, offline stand-in for the LLM. Builds a grounded answer by
    extracting the context sentences that overlap the question's keywords, and
    cites the documents they came from. No overlap -> refusal (no fabrication)."""

    name = "fake"

    def answer(self, question: str, context: list[Chunk]) -> str:
        q_keys = _keywords(question)

        scored: list[tuple[int, str, str]] = []  # (overlap, sentence, doc_id)
        for chunk in context:
            for sentence in re.split(r"(?<=[.!?])\s+", chunk.text.strip()):
                if not sentence:
                    continue
                overlap = len(q_keys & _keywords(sentence))
                if overlap > 0:
                    scored.append((overlap, sentence.strip(), chunk.doc_id))

        if not scored:
            return json.dumps({"answer": REFUSAL, "citations": [], "confidence": 0.0})

        scored.sort(key=lambda t: (-t[0], t[1]))
        top = scored[:2]
        answer_text = " ".join(s for _, s, _ in top)
        citations = list(dict.fromkeys(doc_id for _, _, doc_id in top))
        confidence = min(0.5 + 0.15 * top[0][0], 0.95)

        return json.dumps({
            "answer": answer_text,
            "citations": citations,
            "confidence": round(confidence, 2),
        })


class GeminiModelClient(ModelClient):
    """Real LLM via Gemini. Only constructed when AGENT_MODEL=gemini. Imported
    lazily so the default (fake) run needs nothing installed."""

    name = "gemini"

    def __init__(self, model_name: str = "gemini-1.5-flash"):
        api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise RuntimeError("AGENT_MODEL=gemini but no GEMINI_API_KEY/GOOGLE_API_KEY is set.")
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self._model = genai.GenerativeModel(model_name)

    def answer(self, question: str, context: list[Chunk]) -> str:
        context_block = "\n\n".join(f"[{c.doc_id}] {c.text}" for c in context)
        prompt = (
            "You are a knowledge assistant. Answer ONLY using the context below.\n"
            "Cite the doc_id(s) you used. If the context does not answer the "
            f"question, set answer to exactly '{REFUSAL}'.\n"
            'Return STRICT JSON: {"answer": str, "citations": [doc_id,...], "confidence": 0..1}\n\n'
            f"CONTEXT:\n{context_block}\n\nQUESTION: {question}\n\nJSON:"
        )
        resp = self._model.generate_content(prompt, generation_config={"temperature": 0.0})
        return resp.text.strip()


def get_model_client() -> ModelClient:
    """Factory: choose the model from the AGENT_MODEL env var (default: fake)."""
    if os.environ.get("AGENT_MODEL", "fake").lower() == "gemini":
        return GeminiModelClient()
    return FakeModelClient()
