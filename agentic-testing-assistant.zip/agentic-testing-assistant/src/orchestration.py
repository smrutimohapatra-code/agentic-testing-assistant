"""
orchestration.py - Review Area 4: approvals, handoffs, scoped backend actions.

1. PAUSE FOR APPROVAL, RESUME WITH MEMORY
   A change request (e.g. "submit a correction to the knowledge base") is NOT
   applied immediately. The orchestrator pauses, remembers the pending action by
   a token, and only a caller with the right SCOPE (a maintainer) can approve it.

2. SCOPED BACKEND PERMISSIONS
   The backend checks the caller's scope before running - the stand-in for an
   MCP tool call with a scoped permission. Submitting needs 'submit_change';
   approving needs 'approve_change'.

3. HANDOFF BETWEEN TWO AGENTS, ONE TRACE
   If the primary agent cannot answer, it HANDS OFF to an EscalationAgent that
   owns raising a support ticket - and OWNS ITS OWN RETRIES. A single trace is
   threaded through both agents.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass, field

from src.agent import Agent, REFUSAL_MESSAGE, Span

SCOPES = {
    "contributor": {"submit_change"},
    "maintainer": {"submit_change", "approve_change"},
}

_ACTION_KEYWORDS = ("submit a correction", "request to add", "propose an update",
                    "report an error", "suggest a change", "submit a change")


class KnowledgeBackend:
    """Fake knowledge-base backend. In a real build these calls go through MCP
    with a scoped token; here the scope is checked in-process."""

    def __init__(self):
        self.changes: list[dict] = []
        self.tickets: list[dict] = []
        self._fail_ticket_once = False  # test hook: force one handoff failure

    def apply_change(self, args: dict, caller_role: str, trace: list[Span]) -> dict:
        if "submit_change" not in SCOPES.get(caller_role, set()):
            raise PermissionError(f"{caller_role} lacks 'submit_change' scope")
        rec = {"id": len(self.changes) + 1, **args}
        self.changes.append(rec)
        trace.append(Span("backend", f"apply_change ok, id={rec['id']}"))
        return rec

    def create_ticket(self, question: str, trace: list[Span]) -> dict:
        if self._fail_ticket_once:
            self._fail_ticket_once = False
            raise ConnectionError("ticketing service timeout")
        t = {"id": len(self.tickets) + 1, "question": question}
        self.tickets.append(t)
        trace.append(Span("backend", f"ticket created, id={t['id']}"))
        return t


class EscalationAgent:
    """Second agent. Owns raising a ticket for questions the primary agent can't
    answer - AND owns its own retries for that action."""

    name = "escalation"

    def __init__(self, backend: KnowledgeBackend, max_retries: int = 2):
        self.backend = backend
        self.max_retries = max_retries

    def handle(self, question: str, trace: list[Span]) -> str:
        for attempt in range(1, self.max_retries + 1):
            try:
                trace.append(Span("handoff", f"escalation attempt {attempt}"))
                ticket = self.backend.create_ticket(question, trace)
                return f"I've escalated this to a human expert. Ticket #{ticket['id']} was created."
            except Exception as e:
                trace.append(Span("handoff_error", f"attempt {attempt} failed: {e}"))
        return "I couldn't raise a ticket automatically. Please contact a maintainer directly."


@dataclass
class PendingAction:
    question: str
    user_role: str


@dataclass
class OrchestratorResult:
    answer: str
    trace: list[Span] = field(default_factory=list)
    needs_approval: bool = False
    token: str | None = None
    handoff: bool = False


class Orchestrator:
    def __init__(self, agent: Agent | None = None, backend: KnowledgeBackend | None = None):
        self.agent = agent or Agent()
        self.backend = backend or KnowledgeBackend()
        self.escalation = EscalationAgent(self.backend)
        self._pending: dict[str, PendingAction] = {}  # memory across the pause

    def handle(self, question: str, user_role: str = "contributor") -> OrchestratorResult:
        trace: list[Span] = []

        # 1. Change request -> PAUSE for approval (do not apply yet).
        if any(k in question.lower() for k in _ACTION_KEYWORDS):
            token = secrets.token_hex(4)
            self._pending[token] = PendingAction(question, user_role)
            trace.append(Span("approval", f"action paused; needs approval; token={token}"))
            return OrchestratorResult(
                "This change needs maintainer approval before I can apply it.",
                trace, needs_approval=True, token=token,
            )

        # 2. Normal question -> primary agent.
        result = self.agent.answer(question)
        trace.extend(result.trace)

        # 3. Primary couldn't answer (and wasn't a blocked/injection) -> HANDOFF.
        if result.answer.answer == REFUSAL_MESSAGE and not result.blocked:
            trace.append(Span("handoff", "primary agent refused -> escalation agent"))
            msg = self.escalation.handle(question, trace)
            return OrchestratorResult(msg, trace, handoff=True)

        return OrchestratorResult(result.answer.answer, trace)

    def resume(self, token: str, approver_role: str, approved: bool) -> OrchestratorResult:
        trace: list[Span] = []
        pending = self._pending.get(token)
        if pending is None:
            return OrchestratorResult("Unknown or expired approval token.", trace)
        if "approve_change" not in SCOPES.get(approver_role, set()):
            trace.append(Span("approval", f"DENIED: {approver_role} lacks 'approve_change' scope"))
            return OrchestratorResult("You are not authorised to approve this change.", trace)
        if not approved:
            del self._pending[token]
            trace.append(Span("approval", "rejected by approver"))
            return OrchestratorResult("The change was rejected by the approver.", trace)
        rec = self.backend.apply_change({"request": pending.question},
                                        caller_role=approver_role, trace=trace)
        del self._pending[token]
        return OrchestratorResult(f"Approved and applied. Reference #{rec['id']}.", trace)


if __name__ == "__main__":
    orch = Orchestrator()

    print("=== 1) Change request -> pauses for approval ===")
    paused = orch.handle("Please submit a correction to the grounding entry", user_role="contributor")
    print("Agent:", paused.answer, "| token:", paused.token)
    for s in paused.trace:
        print("   ", s.name, "-", s.info)

    print("\n=== 2) Contributor tries to approve (no scope) -> denied ===")
    denied = orch.resume(paused.token, approver_role="contributor", approved=True)
    print("Agent:", denied.answer)

    print("\n=== 3) Maintainer approves -> backend action runs ===")
    done = orch.resume(paused.token, approver_role="maintainer", approved=True)
    print("Agent:", done.answer)

    print("\n=== 4) Unanswerable question -> handoff to escalation agent ===")
    esc = orch.handle("What is the capital of France?")
    print("Agent:", esc.answer)
    for s in esc.trace:
        print("   ", s.name, "-", s.info)
