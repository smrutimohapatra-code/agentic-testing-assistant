"""
schema.py - the data shapes the system passes around, and the structured-output
validator for the model's response (Review Area 1 - structured outputs).

An LLM returns free text. We force it to return a strict JSON object and then
VALIDATE that object here. Malformed JSON, missing fields, or wrong types raise
SchemaError instead of flowing downstream.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field


@dataclass
class Chunk:
    doc_id: str          # e.g. "grounding" (stable id used in citations)
    source: str          # e.g. "grounding.txt"
    text: str            # the actual paragraph
    score: float = 0.0   # retrieval relevance score


@dataclass
class AgentAnswer:
    answer: str
    citations: list[str] = field(default_factory=list)
    confidence: float = 0.0


# Sentinel the model returns when the corpus cannot answer the question.
REFUSAL = "INSUFFICIENT_CONTEXT"


class SchemaError(ValueError):
    """Raised when the model's raw output does not match the required schema."""


def parse_answer(raw: str) -> AgentAnswer:
    """Parse and VALIDATE the model's raw string into an AgentAnswer.

    Expected JSON: {"answer": "<text>", "citations": ["grounding"], "confidence": 0.9}
    Raises SchemaError on anything malformed. This is the structured-output guard.
    """
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise SchemaError(f"Model output is not valid JSON: {e}") from e

    if not isinstance(data, dict):
        raise SchemaError(f"Expected a JSON object, got {type(data).__name__}")

    for required in ("answer", "citations", "confidence"):
        if required not in data:
            raise SchemaError(f"Missing required field: '{required}'")

    if not isinstance(data["answer"], str):
        raise SchemaError("Field 'answer' must be a string")
    if not isinstance(data["citations"], list) or not all(isinstance(c, str) for c in data["citations"]):
        raise SchemaError("Field 'citations' must be a list of strings")
    if not isinstance(data["confidence"], (int, float)):
        raise SchemaError("Field 'confidence' must be a number")

    confidence = float(data["confidence"])
    if not (0.0 <= confidence <= 1.0):
        raise SchemaError(f"Field 'confidence' out of range [0,1]: {confidence}")

    return AgentAnswer(
        answer=data["answer"],
        citations=data["citations"],
        confidence=confidence,
    )
