"""
retriever.py - the "R" (Retrieval) in RAG.

Loads the knowledge documents from corpus/, splits them into paragraph chunks,
and returns the chunks most relevant to a question.

DESIGN NOTE (declared weakness W1): retrieval is LEXICAL (keyword overlap), not
semantic (embeddings). Simple and fully explainable; the upgrade path is
embeddings + a vector store.
"""

from __future__ import annotations

import re
from pathlib import Path

from src.schema import Chunk

CORPUS_DIR = Path(__file__).resolve().parent.parent / "corpus"

_STOPWORDS = {
    "a", "an", "the", "is", "are", "am", "do", "does", "how", "what", "when",
    "where", "which", "who", "can", "i", "we", "you", "to", "of", "for", "in",
    "on", "my", "me", "and", "or", "per", "much", "many", "get", "got", "have",
    # Low-signal temporal words - kept in sync with model_client.py
    "year", "years", "next", "day", "days", "week", "weeks", "month", "months",
    "time", "calendar", "last", "upcoming", "will", "be",
}


def _keywords(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return {w for w in words if w not in _STOPWORDS and len(w) > 2}


def load_chunks(corpus_dir: Path = CORPUS_DIR) -> list[Chunk]:
    """Read every .txt file in the corpus and split it into paragraph chunks."""
    chunks: list[Chunk] = []
    for path in sorted(corpus_dir.glob("*.txt")):
        raw = path.read_text(encoding="utf-8")
        m = re.search(r"DOC_ID:\s*(\S+)", raw)
        doc_id = m.group(1) if m else path.stem
        body = re.sub(r"^(DOC_ID|TITLE):.*$", "", raw, flags=re.MULTILINE).strip()
        for para in re.split(r"\n\s*\n", body):
            para = para.strip()
            if para:
                chunks.append(Chunk(doc_id=doc_id, source=path.name, text=para))
    return chunks


class Retriever:
    def __init__(self, chunks: list[Chunk] | None = None, min_score: float = 2.0):
        self.chunks = chunks if chunks is not None else load_chunks()
        # Minimum keyword overlap for a chunk to count as evidence. Requiring >= 2
        # stops a single shared high-frequency word (e.g. "test" in "cricket test
        # match") from triggering an answer. See security/red_team.md.
        self.min_score = min_score

    def retrieve(self, question: str, k: int = 3) -> list[Chunk]:
        """Return the top-k chunks whose keyword overlap meets min_score. An
        off-topic question returns [] and the agent refuses."""
        q_keys = _keywords(question)
        scored: list[Chunk] = []
        for chunk in self.chunks:
            overlap = len(q_keys & _keywords(chunk.text))
            if overlap >= self.min_score:
                scored.append(Chunk(doc_id=chunk.doc_id, source=chunk.source,
                                    text=chunk.text, score=float(overlap)))
        scored.sort(key=lambda c: (-c.score, c.doc_id))
        return scored[:k]
