# Agentic AI Testing Knowledge Assistant

A grounded (RAG) AI agent that answers questions about the **agentic-AI testing
concepts** taught in the TAE -> Agentic AI track, cites the source concept for
every answer, and refuses rather than fabricates when the corpus cannot answer.
Built as the track capstone - a test engineer's agent, grounded in the track's
own material.

- **Design & decisions:** [`SYSTEM.md`](SYSTEM.md)
- **How to run (no API key needed):** [`RUN.md`](RUN.md)
- **Model card:** [`docs/model_card.md`](docs/model_card.md)
- **Red-team report:** [`security/red_team.md`](security/red_team.md)

## Quick start
```bash
pip install -r requirements.txt
python -m pytest -q                 # 19 passed
python -m eval.run_eval             # GATE PASSED
python -m src.agent "How do you test a system that gives a different answer every time?"
```

## What it demonstrates
| Area | Where |
|------|-------|
| Testing non-determinism + structured output | `tests/`, `src/schema.py`, deterministic fake model |
| Grounded agent core (citations, recovery, refusal) | `src/agent.py`, `src/retriever.py` |
| Evaluation, observability, red teaming | `eval/`, the trace, `security/red_team.md` |
| Orchestration (approval, handoff, scoped backend) | `src/orchestration.py` |
| Quality gate + capstone | `.github/workflows/eval-gate.yml`, `docs/model_card.md` |

The default model is a deterministic offline stand-in, so everything runs with no
cloud spend. Set `AGENT_MODEL=gemini` (with an API key) to use a real LLM.
