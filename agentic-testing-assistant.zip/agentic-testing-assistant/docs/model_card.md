# Model Card - Agentic AI Testing Knowledge Assistant

**Version:** 1.0  ·  **Owner:** Smruti Ranjan Mohapatra  ·  **Type:** Grounded (RAG) conversational agent

## Intended use
Answers questions about **agentic-AI testing concepts** (testing non-determinism,
grounding, evaluation, observability, red teaming, orchestration, quality gates,
continuous evaluation) using **only** the curated concept corpus, with a citation
to the source concept for every answer.

- **Primary users:** test engineers learning or applying agentic-AI testing.
- **Out of scope:** anything not in the corpus. These are refused or escalated.

## How it works
Retrieve relevant concept chunks -> answer only from them and cite the source ->
validate the response schema -> verify every citation resolves -> redact PII ->
return. Every step is traced. See `SYSTEM.md` for the full design.

## Capabilities
- Grounded answers with resolving citations to the concept docs.
- Refuses (does not fabricate) when the corpus cannot answer.
- Recovers from a failed retrieval tool; bounded by a max-iteration guard.
- Blocks prompt injection and redacts PII.
- Pauses change requests for scoped maintainer approval; hands off unanswerable
  questions to an escalation agent.

## Evaluation (golden set v1.0, fake model)
- Code-based pass-rate: **100% (12/12)**  ·  CI gate threshold: **85%**.
- Checks split: **code** for exact facts/citations/refusal; **LLM-judge** for relevance.

## Known failure modes
| Failure mode | Frequency | Mitigation |
|--------------|-----------|------------|
| Lexical retrieval misses paraphrases (no shared word) | Medium | Planned: semantic (embedding) retrieval |
| Off-topic question sharing a single common word | Low (mitigated) | Require >= 2 keyword overlap (`min_score`) |
| Deterministic fake model does not exercise LLM fluency | By design (local) | `AGENT_MODEL=gemini` for a live run |

## A failure mode to raise with a client before relying on this
Because retrieval is lexical, the agent can **miss** a relevant concept phrased
differently from the question (a false refusal). For production use this should
be upgraded to semantic retrieval and measured against a larger golden set.
