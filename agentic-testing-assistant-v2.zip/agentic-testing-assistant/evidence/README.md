# Evidence Folder — the thirteen track artefacts

This folder collects the thirteen artefacts the Engineer Guide (Step 4) asks for
and points to where each one lives in this repository. Everything here already
exists from the modules; this index is the map a reviewer can follow.

Two artefacts are **honestly declared as gaps** (Modules 10 and 12) — see the last
rows. Per the guide, a missing artefact *with an explanation* is a smaller problem
than a silent one.

| # | Module / Sprint | Artefact the guide asks for | Where it is in this repo | How to see it |
|---|-----------------|------------------------------|--------------------------|---------------|
| 1 | Sprint 0 — Decision & Setup | Decision record + written answer on verifying a system that gives a different answer every time | [`SYSTEM.md`](../SYSTEM.md) design decision #1; [`src/model_client.py`](../src/model_client.py) | Read decision #1: the model sits behind an interface with a **deterministic FakeModelClient** default — that is the answer to "how do you test a non-deterministic system." |
| 2 | Sprint 1 — AI-Assisted Testing | A real test suite, running green, with the specs that produced it | [`tests/`](../tests/) (19 tests) | `python -m pytest -v` → 19 passed. Each test name states what it verifies. |
| 3 | Sprint 2 — Structured Outputs | Structured-output service with tests that catch malformed and out-of-distribution responses | [`src/schema.py`](../src/schema.py), [`tests/test_structured_output.py`](../tests/test_structured_output.py) | `parse_answer()` validates JSON shape, types and ranges; 6 tests reject malformed / out-of-range output. |
| 4 | Sprint 3 — Agent Fundamentals | Agent core + a run recovering from a failed/timed-out tool call | [`src/agent.py`](../src/agent.py), [`tests/test_tool_recovery.py`](../tests/test_tool_recovery.py) | `_retrieve_with_recovery()` + `max_tool_retries`; 2 tests prove recovery after a tool failure. |
| 5 | Sprint 4 — The Grounded Agent | Cited answers you can check against their sources | [`src/retriever.py`](../src/retriever.py), [`corpus/`](../corpus/), [`tests/test_grounding.py`](../tests/test_grounding.py) | `python -m src.agent "What stops an agent loop from running forever?"` → answer **with a `Citations:` line** naming the source concept. |
| 6 | Sprint 5 — Evaluation as Engineering | Evaluation suite + written error analysis naming top failure modes | [`eval/golden_dataset.json`](../eval/golden_dataset.json), [`eval/evaluators.py`](../eval/evaluators.py), [`eval/run_eval.py`](../eval/run_eval.py), [`security/red_team.md`](../security/red_team.md) | `python -m eval.run_eval` → GATE PASSED (100%). Top failure mode (single-word false-answer) analysed in red_team.md #4. |
| 7 | Sprint 6 — Observability & Trace Debugging | A trace walkthrough locating the failing span behind a degraded response | [`src/agent.py`](../src/agent.py) — `Span` / `pretty_trace()` | Every run prints a step-by-step `Trace`. The cricket false-answer was located via the retrieval span (see red_team.md #4). |
| 8 | Sprint 7 — Red Teaming | Red-team report, the guardrails that closed each hole, and the passing re-test | [`security/red_team.md`](../security/red_team.md), [`src/guardrails.py`](../src/guardrails.py), [`tests/test_guardrails.py`](../tests/test_guardrails.py) | 4 attacks (injection, PII leak, hallucinated citation, single-word false-answer), each with the fix and a passing re-test. |
| 9 | Sprint 8 — Orchestration & Protocol | Paused-and-resumed run with an MCP action + A2A handoff contract with its failed-handoff trace | [`src/orchestration.py`](../src/orchestration.py), [`tests/test_orchestration.py`](../tests/test_orchestration.py) | `python -m src.orchestration` → change **pauses for approval**, contributor **denied** (scope), maintainer **approves**; unanswerable question **hands off** to the escalation agent (ticket); one trace spans both. |
| 10 | Sprint 9 — Computer-Use / Browser Agents | A browser agent completing a real web workflow and recovering from an error | **GAP — declared.** Not implemented. See [`SYSTEM.md`](../SYSTEM.md) weakness **W3**. | Its role (an external action that pauses, is scoped, and can fail/recover) is **simulated** by the scoped backend + escalation handoff in `src/orchestration.py`. A real browser agent is the documented upgrade path. |
| 11 | Sprint 10 — Quality Gates, CI & Deployment | The pipeline eval gate blocking a regression + the deployment configuration | [`.github/workflows/eval-gate.yml`](../.github/workflows/eval-gate.yml), [`eval/run_eval.py`](../eval/run_eval.py) | The gate runs tests + eval on every push and **fails the build if the score drops below 85%** (exit code), blocking the regression. |
| 12 | Sprint 10 (cont.) — Continuous Evaluation | Continuous-eval loop, a quality alert that fired, and the response it triggered | **PARTIAL — declared.** See [`SYSTEM.md`](../SYSTEM.md) weakness **W3**. | The same golden-set scorer + 85% threshold is the alert logic; run locally it is the "replayed sample" the guide's Section 6 substitution describes. Production drift alerting + auto-rollback are the documented upgrade path, not implemented. |
| 13 | Sprint 11 — Capstone | Model card + recorded walkthrough | [`docs/model_card.md`](../docs/model_card.md), [`SYSTEM.md`](../SYSTEM.md), walkthrough recording (handed over separately) | The model card states purpose, inputs/outputs, limitations and intended use; the 10-minute walkthrough recording is in the submission. |

## Summary of gaps (also in SYSTEM.md, weakness W3)

- **Module 10 (browser agent):** not implemented. Its behaviour — an external action
  that pauses for approval, runs under a limited scope, and can fail and recover —
  is simulated by the scoped backend and escalation handoff in `src/orchestration.py`.
- **Module 12 (continuous evaluation):** partially present. The local golden-set
  scorer with the 85% gate is the alert logic; production drift monitoring and
  automatic rollback are documented as the upgrade path, not built.

Both gaps are out of scope for an **offline, zero-cost** review (Engineer Guide
Section 6), and both are declared openly rather than hidden.
