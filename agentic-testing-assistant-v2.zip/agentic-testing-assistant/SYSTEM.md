# SYSTEM.md - Agentic AI Testing Knowledge Assistant

## What it is (two sentences)
A grounded (RAG) agent that answers questions about the agentic-AI testing
concepts taught in this track, using only a curated concept corpus and citing the
source concept for every answer. It is fail-closed: bad input, a failed tool,
malformed model output, or an unresolved citation all end in a safe refusal.

## Architecture / data flow
```
question
  -> input guardrail (block prompt injection)       src/guardrails.py
  -> retrieve concept chunks (min_score, tool retry) src/retriever.py
  -> model answers from context, strict JSON         src/model_client.py
  -> validate schema (retry up to max_iterations)    src/schema.py
  -> verify every citation resolves, else refuse     src/agent.py
  -> output guardrail (redact PII) -> answer+trace   src/guardrails.py
```
Orchestration (`src/orchestration.py`) adds approval pause/resume with scoped
permissions and a handoff to an escalation agent.

## Why this subject
The corpus is the track's own testing knowledge, so the agent demonstrates every
capability (grounding, citations, refusal, evaluation, red teaming, orchestration)
on content a test engineer and a reviewing test engineer both know well.

## Key design decisions (and the alternative rejected)
1. **Model behind an interface; deterministic FakeModelClient as default.**
   Rejected calling a live LLM in tests/local runs: non-deterministic, costs
   money, cannot run offline. `GeminiModelClient` drops in via the same interface.
2. **Lexical retrieval with a min-overlap threshold.** Rejected embeddings +
   vector DB: heavier deps, not runnable on a clean checkout in <15 min. Chosen
   for explainability; `min_score=2` closes the single-word false-answer hole;
   full upgrade path documented as weakness W1.
3. **Fail-closed with citation verification.** Rejected trusting the model's
   self-reported citations - that is how hallucinations ship.
4. **Plain Python, no agent framework.** Rejected LangGraph/LangChain: more
   hidden control flow, harder to explain and modify live.
5. **Rule-based guardrails.** Rejected LLM-based guardrails: slower, costly,
   non-deterministic. Rules are exact and testable for the known attack set.
6. **In-process scoped backend simulating MCP.** Rejected standing up a real MCP
   server for a local review: unnecessary infra; scope checks are labelled.

## Module -> review-area -> artefact map
The thirteen track artefacts are collected and indexed in [`evidence/README.md`](evidence/README.md),
which maps each module to its file(s) in this repo and explains the two declared gaps.

| Module(s) | Area | Artefact in this repo |
|-----------|------|------------------------|
| 1-3  | 1 Testing / structured output | `tests/`, `src/schema.py`, deterministic `FakeModelClient` |
| 4    | 2 Agent core | `src/agent.py` (loop, max-iter guard, tool recovery) |
| 5    | 2 Grounding | `src/retriever.py`, citation check, refusal |
| 6    | 3 Evaluation | `eval/golden_dataset.json`, `evaluators.py`, `run_eval.py` |
| 7    | 3 Observability | the `trace` (Span list) in `agent.py` |
| 8    | 3 Red teaming | `security/red_team.md` + guardrail tests |
| 9    | 4 Orchestration/handoff | `src/orchestration.py` (approval, handoff, one trace) |
| 10   | 4 Browser agent | not implemented - weakness W3 |
| 11   | 5 Quality gate | `.github/workflows/eval-gate.yml` |
| 12   | 5 Continuous eval | partially simulated - weakness W3 |
| 13   | 5 Capstone | `docs/model_card.md` + this file |

## My three known weaknesses (declared)
- **W1 - Lexical retrieval, not semantic.** It matches on shared words, so it can
  miss a concept phrased differently from the question (a false refusal). The
  single-common-word false-answer was found and fixed (`min_score=2`, see
  red_team #4); the honest full fix is embedding-based retrieval.
- **W2 - Default model is a deterministic fake.** Makes the system testable
  offline, but local runs do not exercise a real LLM's fluency. `GeminiModelClient`
  exists via the same interface but is lightly exercised (no key in review env).
- **W3 - Area 4/5 partially simulated.** Approval + handoff are real and tested,
  but a true browser agent (Module 10) and production drift/alerting with
  auto-rollback (Module 12) are not implemented; optional builds 14-16 not taken.

## Missing artefacts - explanation
The browser agent, live drift monitoring, and a cloud deployment are intentionally
out of scope for an offline, zero-cost review. Their roles are either simulated
(scoped backend, escalation handoff) or documented as upgrade paths. Nothing here
depends on cloud spend to run or to review.

## Pairing declaration
This system was built by me during the track. I used a coding assistant to help
write and explain the code (permitted by the guide); the design decisions,
trade-offs, and this write-up are my own. No other engineer co-authored it.
